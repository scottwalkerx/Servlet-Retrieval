import java.sql.Connection;
import java.sql.DriverManager;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class pets
 */
public class pets {
	
	pets() {};
	
	public pets(String id, String name2, String color2, int price2) {
		// TODO Auto-generated constructor stub
	}

	String product_id, name, color;
	int price;

     // Connection conn = DriverManager.getConnection(url, user, password);
    
    
	public String getProduct_id()
	{ return product_id; }

	public void setProduct_id(String product_id) 
	{ this.product_id = product_id;	}


	public String getName() 
	{return name; }

	public void setName(String name) 
	{this.name = name; }


	public String getColor() 
	{	return color;}

	public void setColor(String color) 
	{	this.color = color;	}


	public int getPrice() 
	{	return price;}

	public void setPrice(int price2) 
	{this.price = price2;}


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
