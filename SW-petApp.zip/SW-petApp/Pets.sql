CREATE TABLE pets (
  `product_id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `color` varchar(15) DEFAULT NULL,
  `price` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`product_id`) 
); -- creating a table that hold product details

INSERT INTO pets (product_id, name, color, price) values
 (1, 'Dalmatian', 'Black & White', '$500');
 
INSERT INTO pets (product_id, name, color, price) values
 (2, 'Husky', 'Grey & White', '$700');

INSERT INTO pets (product_id, name, color, price) values
 (3, 'Rottweiler', 'Brown', '$800');

 INSERT INTO pets (product_id, name, color, price) values
 (4, 'Poodle', 'Grey', '$800');

insert into pets (product_id, name, color, price) values
 (5, 'Choclate Lab', 'Brown', '$500');

SELECT * FROM pets;